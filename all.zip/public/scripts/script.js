let dayT = 15, hourT = 1,minuteT = 1, secondT = 15;

const day = document.querySelector('.day');
const hour = document.querySelector('.hour');
const minute = document.querySelector('.minute');
const second = document.querySelector('.second');
day.innerText = dayT;
hour.innerText = hourT;
minute.innerText = minuteT;
second.innerText = secondT;
const id = setInterval(() => {
    secondT--;
    second.innerText = secondT;

    if(secondT <= 0) {
        secondT = 59;
        minuteT--;
        minute.innerText = minuteT;

        if(minuteT <= 0) {
            minuteT = 59;
            minute.innerText = minuteT;
            hourT--;
            hour.innerText = hourT;
            if(hourT <= 0) {
                hourT = 24;
                hour.innerText = hourT;
                dayT--;
                day.innerText = dayT;
                if(dayT <= 0) {
                    clearInterval(id);
                    console.log('finishe')
                }
            }
        }
    }
}, 1000)
